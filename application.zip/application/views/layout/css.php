<!-- Main CSS -->
<link rel="stylesheet" href="<?= base_url(); ?>assets/css/main/app.css">
<link rel="stylesheet" href="<?= base_url(); ?>assets/css/main/app-dark.css">
<link rel="stylesheet" href="<?= base_url(); ?>assets/extensions/@fortawesome/fontawesome-free/css/all.min.css">
<link rel="stylesheet" href="<?= base_url(); ?>assets/extensions/choices.js/public/assets/styles/choices.css">
<link rel="stylesheet" href="<?= base_url(); ?>assets/extensions/datatables.net-bs5/css/dataTables.bootstrap5.min.css" />
<style>
    .sidebar-wrapper .sidebar-header img {
        height: 2.9rem !important;
        margin-left: -20px !important;
    }
</style>
<!-- Tutup Main CSS -->